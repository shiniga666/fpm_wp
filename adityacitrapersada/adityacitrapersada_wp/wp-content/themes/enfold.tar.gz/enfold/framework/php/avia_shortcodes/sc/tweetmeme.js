scnShortcodeMeta = {
    attributes: [{
        label: "Style",
        id: "style",
        help: "Values: &lt;empty&gt; or compact."
    }, {
        label: "link",
        id: "link",
        help: "Optional. Specify URL directly."
    }, {
        label: "Source",
        id: "source",
        help: "Optional username."
    }],
    defaultContent: "",
    shortcode: "tweetmeme"
};